# A3C Blog Post
In order to run this code, you will need the following prerequisites:

* [OpenAI Gym](https://github.com/openai/gym) - `pip install gym`
* [pyglet](https://bitbucket.org/pyglet/pyglet/wiki/Home) - `pip install pyglet` 
* [TensorFlow](https://www.tensorflow.org/install/) - `pip install tensorflow==2.2.0`
